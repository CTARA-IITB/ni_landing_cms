
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
<title>Nutrition India</title>
<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="dashboard.css">
<link rel="stylesheet" type="text/css" href="responsive.css">
</head>
<body>
	<div class="container-fluid px-0">
		<div class="header" id="myHeader">
			<div class="row w-100 p-0 m-0">
				<div class="d-flex col-12 align-items-center p-4 main-head">
					<div class='col-4 text-left'><img src="images/mhf.png" class="health-ministry"></div>
					<div class='col-4 text-center'><img src="images/nutrition-logo.svg" class="nutrition-india"></div>
					<div class='col-4 text-right'><img src="images/pa.png" class="poshan-abhiyan"></div>
				</div>
			</div>
			<div class="row w-100 p-4 for-mobile i-for-mobile-div1" style="margin: 0;">
				<div class="col-6 col-lg-4 col-md-6 p-3 for-mobile-1">
					<div class="d-flex top-15" style="position: relative;">
						<img src="images/lifecycle/Pregnancy.png" class="lifecycle-img">
						<div class="select-lifecycle-parent">
							<div class="select-lifecycle-child">
								<select class="select-lifecycle">
									<option>Early Childhood</option>
									<option>Pregnancy</option>
									<option>Adolescence</option>
								</select>
							</div>
							<div class="select-lifecycle-cat-child">
								<select class="select-category">
									<option>Manifestation</option>
									<option>Intervention</option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<div class="col-12 col-lg-7 col-md-12 p-3 for-mobile-3">
					<div class="row">
						<div class="col-6 col-lg-3 p-2">
							<div>
								<select class="select-border w-100">
									<option>Select an indicator</option>
									<option>Indicator 1</option>
									<option>Indicator 2</option>
									<option>Indicator 3</option>
									<option>Indicator 4</option>
								</select>
							</div>
						</div>
						<div class="col-6 col-lg-3 p-2">
							<div class="toogle-button">
								<ul class="nav nav-tabs d-flex" id="myTab" role="tablist">
			                        <li class="nav-item">
			                            <a class="nav-link active" id="Prevalence" data-toggle="tab" href="#login_form" role="tab" aria-controls="Prevalence" aria-selected="true">Prevalence</a>
			                        </li>
			                        <li class="nav-item">
			                            <a class="nav-link radius" id="Burden" data-toggle="tab" href="#signup_form" role="tab" aria-controls="Burden" aria-selected="false">Burden</a>
			                        </li>
		                    	</ul>
							</div>
						</div>
						<div class="col-6 col-lg-3 p-2">
							<div>
								<select class="select-border w-100">
									<option>Select a region</option>
									<option>Adolescence</option>
								</select>
							</div>
						</div>
						<div class="col-6 col-lg-3 p-2">
							<div>
								<select class="select-border w-100">
									<option>Select a survey</option>
									<option>Adolescence</option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<div class="col-6 col-lg-1 col-md-6 p-3 for-mobile-2 i-for-mobile-div3">
					<div class="i-class">
						<img src="images/i-icon.png" class="i-icon">
					</div>
				</div>
			</div>
		</div>
		<div class="row w-100 p-4" style="margin: 0;">
			<div class="col-12 col-lg-6 col-md-12 p-3">
				<img src="images/img1.png" class="img-map">
			</div>
			<div class="col-12 col-lg-6 col-md-12 p-3">
				<img src="images/img2.png" class="img-map">
			</div>
			<div class="col-12 col-lg-6 col-md-12 p-3">
				<img src="images/img3.png" class="img-map">
			</div>
			<div class="col-12 col-lg-6 col-md-12 p-3">
				<img src="images/img4.png" class="img-map">
			</div>
		</div>
		<div>
		
		</div>
		<footer class="footer p-0 mt-4">
			<div class="row  p-0 m-0 align-items-center">
				<div class="col-3">
					<a href="https://nutritionindia.info/" target="_blank"><img src="images/nutrition-logo-footer.svg" class="nutrition-image"></a>
				</div>
				<div class="col-3">
					<a href="https://www.ctara.iitb.ac.in/" target="_blank"><img src="images/ctara-logo.png" title="CTARA" class="iitb-image"></a>
				</div>
				<div class="col-3">
					<a href="https://proditech.in" target="_blank"><img src="images/proditech-logo.png" title="Nutrition India, Website developed by PRODITECH Solutions, Mumbai." class="proditech-image"></a>
				</div>
				<div class="col-3">
					<a href="http://unicef.in/" target="_blank"><img src="images/unicefLogo.png"  class="unichef-image"></a>
				</div>
			</div> 
		</footer>
		
	</div>
</body>
</html>
<script type="text/javascript">
	window.onscroll = function() {myFunction()};

	var header = document.getElementById("myHeader");
	var sticky = header.offsetTop;

	function myFunction() {
	  if (window.pageYOffset > sticky) {
	    header.classList.add("sticky");
	  } else {
	    header.classList.remove("sticky");
	  }
	}
</script>